package com.predescu.authSpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
