package com.predescu.authNoSpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthNoSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
